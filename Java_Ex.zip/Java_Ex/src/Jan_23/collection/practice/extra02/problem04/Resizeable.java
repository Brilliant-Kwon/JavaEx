package Jan_23.collection.practice.extra02.problem04;

public interface Resizeable {

    public void resize(double s);
}
