package Fab_15_JDBC.vo;

public class PhoneBookVO {

}
