package Fab_15_JDBC;

public class PhoneBook {

	public static void main(String[] args) {

	}

}
