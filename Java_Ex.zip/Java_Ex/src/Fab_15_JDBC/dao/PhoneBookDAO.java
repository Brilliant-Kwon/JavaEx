package Fab_15_JDBC.dao;

public interface PhoneBookDAO {

}
