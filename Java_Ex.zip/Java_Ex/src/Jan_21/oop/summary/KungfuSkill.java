package Jan_21.oop.summary;

public interface KungfuSkill {
    void kungfu(); // 추상이지만 표기는 하지 않음

}
