package Jan_21.oop.summary;

public interface Flyable {
    void fly();
}
