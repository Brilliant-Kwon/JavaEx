package Jan_21.oop.shape.v2;

public interface Drawable {
    //추상 메서드 (abstract를 하지 않아도 됨)
    void draw();
//    default void method(){ //가능은 하나... 안 쓰는 것을 추천
//
//    }
}
