package Jan_22.practice.extra01.q03;

public class Q03Test {

	public static void main(String[] args) {
		//	Begin: 이곳의 코드는 수정하지 않습니다.
		Question03 q3 = new Question03();
		q3.printAnswer();
		//	End: 이곳의 코드는 수정하지 않습니다.
		
	}

}
