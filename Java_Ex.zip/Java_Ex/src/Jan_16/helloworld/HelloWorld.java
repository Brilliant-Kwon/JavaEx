package Jan_16.helloworld;

public class HelloWorld {
    public static void main(String[] args) {
        //Hello World 문자열 출력
        System.out.println("Hello World!");
    }
}
