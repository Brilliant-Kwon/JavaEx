package JavaStudy.Jan_29.stack;

public interface Stack {
    int length();

    Object pop();

    boolean push(Object object);

}
