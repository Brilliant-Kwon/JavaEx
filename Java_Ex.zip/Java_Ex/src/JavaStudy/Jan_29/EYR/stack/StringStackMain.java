package JavaStudy.Jan_29.EYR.stack;//package day2.stack;
//
//public class StringStackMain {
//    public static void main(String[] args) {
//        StringStack stack1 = new StringStack(5);
//        stack1.push("A");
//        stack1.push("B");
//        stack1.push("C");
//        stack1.push("D");
//        stack1.push("E");
//        stack1.printStack();
//        
//        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
//    }
//}