package JavaStudy.Jan_29.YSH;

public interface Stack {
	int length();
	Object pop();
	boolean push(Object ob);
}
