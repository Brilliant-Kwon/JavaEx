package JavaStudy.Jan_29.YSH;

public class ColorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyPoint p=new MyColorPoint(2, 3, "blue");
		p.move(3, 4);
		p.reverse();
		p.show();
	}

}
