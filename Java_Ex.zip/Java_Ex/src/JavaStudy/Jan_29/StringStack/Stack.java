package JavaStudy.Jan_29.StringStack;

public interface Stack {
    int length();

    Object pop();

    boolean push(Object object);

}
