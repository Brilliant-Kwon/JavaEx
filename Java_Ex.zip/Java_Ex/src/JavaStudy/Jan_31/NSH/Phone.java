package JavaStudy.Jan_31.NSH;

public class Phone {
	
	
	private String name;
	private String address;
	private String phonenumber;
	public Phone(String name, String address, String phonenumber) {
		this.name = name;
		this.address = address;
		this.phonenumber = phonenumber;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	
	
	
	
}
