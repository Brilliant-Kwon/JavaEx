package JavaStudy.Jan_31.EYR.addressprogram;

public class Address {
	private String name;
	private String home;
	private String phoneNum;

	public Address() {}
	public Address(String name, String home, String phoneNum) {
		this.name = name;
		this.home = home;
		this.phoneNum = phoneNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHome() {
		return home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void Member() {
		System.out.println(name+" "+home+" "+phoneNum);
	}



}
