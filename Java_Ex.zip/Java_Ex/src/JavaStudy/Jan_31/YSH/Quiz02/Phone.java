package JavaStudy.Jan_31.YSH.Quiz02;

public class Phone {
	String addr;
	String phoneNum;
	public Phone(String addr,String phoneNum) {
		this.addr=addr;
		this.phoneNum=phoneNum;
	}
}
