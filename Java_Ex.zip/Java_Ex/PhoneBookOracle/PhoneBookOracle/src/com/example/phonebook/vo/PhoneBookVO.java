package com.example.phonebook.vo;

public class PhoneBookVO {

}
