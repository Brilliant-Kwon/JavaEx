package com.example.phonebook.dao;

public interface PhoneBookDAO {

}
